// model.hpp -- the DESIGN: what the user drew (bodies, shapes, materials, links, environment).
// The design never changes while a simulation runs, except through live property edits.
#pragma once
#include <algorithm>
#include <cmath>
#include <string>
#include <vector>
#include "math.hpp"

namespace vlab {

// ------------------------------------------------------------------ materials
struct Material {
    std::string name = "Custom";
    double density = 1000;     // kg/m^3 (2-D bodies have 1 m depth, so mass = density * area)
    double muS = 0.5;          // static friction coefficient
    double muK = 0.4;          // kinetic (sliding) friction coefficient
    double restitution = 0.3;  // bounciness: 0 = dead, 1 = perfectly elastic
    double rollRes = 0.0;      // rolling resistance coefficient (dimensionless, about 0.001 to 0.05)
    double alphaT = 12e-6;     // coefficient of linear thermal expansion (per kelvin): steel 12e-6, aluminium 23e-6 ...
    double youngs = 200e9;     // Young's modulus E in pascals (stiffness): sets how much a body bends or squashes (deform.hpp)
};

// Generic textbook-level values. Real values depend on surface finish, temperature and speed.
const std::vector<Material>& materialLibrary();
const Material* findMaterial(const std::string& name);

// ------------------------------------------------------------------ shapes
enum class ShapePreset { Circle, Box, Regular, Wedge, Line };   // Line: a zero-thickness segment (floors, walls, ramps)

struct Shape {
    ShapePreset preset = ShapePreset::Circle;
    double radius = 0.5;       // Circle radius, or circumradius of a Regular polygon
    double w = 1.0, h = 1.0;   // Box width/height, Wedge legs
    int sides = 5;             // Regular polygon: 3..12
    // Derived polygon data (empty for circles). Vertices are CCW, centred on the centroid.
    std::vector<Vec2> verts, normals;
    double area = 0;           // m^2
    double inertiaPerMass = 0; // (moment of inertia) / mass, m^2

    bool isCircle() const { return preset == ShapePreset::Circle; }
    void rebuild();            // recompute verts, normals, area, inertiaPerMass from the parameters
    double boundingRadius() const;
};

// ------------------------------------------------------------------ bodies
enum class BodyKind { Dynamic, Static, Anchor };   // Anchor = a fixed point (a pin in the wall)

struct Body {
    std::string name = "Body";
    BodyKind kind = BodyKind::Dynamic;
    Shape shape;
    Material mat;
    bool massFromDensity = false;   // false: use `mass`; true: density * area
    double mass = 1.0;              // kg (used when !massFromDensity)
    Vec2 pos;                       // initial position, metres (y points DOWN, like the screen)
    double angle = 0;               // initial angle, radians
    Vec2 vel;                       // initial velocity, m/s
    double omega = 0;               // initial angular velocity, rad/s
    bool lockX = false, lockY = false, lockRot = false;   // rails / no spin
    bool collide = true;            // may this body collide with other bodies?
    double driveF = 0;              // harmonic push: amplitude (N) ...
    double driveAngleDeg = 0;       // ... direction (0 = right, 90 = down) ...
    double driveW = 0;              // ... and angular frequency (rad/s)
    int secType = 0;                // cross-section of a beam (section.hpp): 0 slab (1 m deep rectangle), 1 rectangle, 2 circle, 3 hollow rectangle, 4 tube, 5 I-beam, 6 T-beam, 7 channel
    double secB = 0.10, secH = 0.20, secTf = 0.012, secTw = 0.008;   // width (or flange width), height (or diameter), flange / wall thickness, web thickness (m)
    double tempDelta = 0;           // temperature change of this body, deg C (thermal expansion)
    double tempGrad = 0;            // temperature of its lower face minus its upper face, deg C (makes a beam bow)
    int dloadType = 0;              // distributed load along a box: 0 none, 1 uniform, 2 triangular rising, 3 falling, 4 peak in the middle, 5 equation (expr.hpp)
    double dloadN = 0;              // its peak intensity in newtons per metre (kg-force per metre = N/m / 9.80665)
    double dloadAngleDeg = 90;      // direction it acts in (0 = right, 90 = down: like gravity)
    double dloadX0 = 0, dloadX1 = -1;   // where along the body it acts: from x0 to x1 metres from the left end (x1 < 0: to the far end)
    std::string dloadExpr = "500*sin(pi*x/L)";   // the formula q(x) in N/m when the type is "equation"
    double loadN = 0;               // a constant LOAD on the centre of mass: magnitude in newtons (kg-force = N / 9.80665) ...
    double loadAngleDeg = 0;        // ... direction (0 = right, 90 = down) ...
    bool loadPull = false;          // ... and push (false) or pull (true: the same line, the opposite way)
    bool loadTimeVar = false;       // the push/pull magnitude is F(t) = loadExpr (newtons, t in seconds) instead of the constant loadN
    std::string loadExpr = "3*t^3 + 2*t^2 + 0*t + 4";
    double momentN = 0;             // a constant MOMENT on the body, N m (positive = clockwise on the screen)
    bool momentTimeVar = false;     // the moment is M(t) = momentExpr instead of the constant momentN
    std::string momentExpr = "20*sin(2*pi*t)";
    double driveT = 0;              // > 0: instead a single half-sine PULSE of this many seconds starting at t = 0 (a gun, a hammer blow)
    unsigned color = 0xFF3574F0;    // ARGB for drawing

    // derived by Model::updateMass()
    double massKg = 1, invMass = 1, inertia = 1, invI = 1;
    bool isDynamic() const { return kind == BodyKind::Dynamic; }
    bool collides() const { return kind != BodyKind::Anchor && collide; }
};

// ------------------------------------------------------------------ links
enum class LinkKind {
    Spring, Damper,
    Rod,       // rigid bar of fixed length
    Pin,       // hinge: two points coincide, bodies may rotate about it (optionally with a motor and rotary damping)
    Weld,      // fixed joint: points coincide AND the relative angle is held (a cantilever support when one body is ground)
    Roller     // a point of body B is held on a line through A's point: slides along A's x axis, rotation free
};

struct Link {
    LinkKind kind = LinkKind::Spring;
    int a = -1, b = -1;       // body indices
    Vec2 la, lb;              // attachment points in each body's local frame (metres)
    double k = 50;            // spring stiffness N/m
    double k3 = 0;            // cubic stiffness N/m^3 (0 = ideal linear spring)
    double L0 = 1;            // spring rest length (m) or rod length (m)
    bool autoRest = true;     // while true, L0 follows the drawn length
    double c = 1.0;           // damper coefficient N s/m
    bool collideConnected = false;   // may the two joined bodies collide with each other?
    double refAngle = 0;      // Weld: held relative angle (B minus A), follows the drawing
    double jointC = 0;        // Pin: rotary damping N m s/rad
    double motorTorque = 0;   // Pin: constant torque on B (and -torque on A), N m
    double motorAmp = 0;      // Pin: harmonic torque amplitude, N m
    double motorW = 0;        // Pin: harmonic torque frequency, rad/s
    double kt = 0;            // Pin: torsional spring stiffness N m/rad about the hinge (0 = free hinge); rest angle = refAngle
    // Distributed spring / damper: the element is spread along a span, from (la, lb) to (la2, lb2) in the two body frames.
    int dist = 0;             // 0 = one element, 1 = constant distribution, 2 = linear distribution
    Vec2 la2, lb2;            // far end of the span on each body (local frames)
    double distM = 0;         // linear distribution: slope per metre of span. Value per metre at distance s along the span is k (or c) + distM * s
    int distN() const { double L = length(la2 - la); return dist ? std::max(4, std::min(40, (int)std::ceil(L / 0.15))) : 1; }
    double distSpan() const { return length(la2 - la); }
};

// ------------------------------------------------------------------ environment
enum class Combine { Geometric, Average, Min, Max };

struct Environment {
    double gravity = 9.81;           // m/s^2 toward +y (down)
    bool realistic = true;           // the master toggle (the individual switches below are what the engine reads)
    bool collisions = true;
    bool friction = true;            // off: every contact is frictionless (mu = 0)
    bool inelastic = true;           // off: every impact is perfectly elastic (e = 1)
    bool rolling = true;             // rolling resistance of circles
    bool damping = true;             // off: dampers are ignored
    double deltaT = 0;               // temperature change applied to every body, deg C (added to each body's own)
    bool deadLoad = false;           // include each beam's own weight (mass per metre x g) as a distributed load in its bending (deform.hpp)
    bool airDrag = false;            // F = -(c1 + c2 |v|) v on every moving body
    double drag1 = 0.0;              // N s/m
    double drag2 = 0.0;              // N s^2/m^2
    Combine muCombine = Combine::Geometric;
    Combine eCombine = Combine::Max;
    double restThreshold = 0.25;     // impacts slower than this (m/s) do not bounce (lets things come to rest)
    int solverIterations = 14;
    double dt = 0.00025;             // physics step in seconds

    void setIdeal();                 // frictionless, perfectly elastic, no drag, no damping
    void setRealistic();             // friction, inelastic impacts, damping, rolling resistance
};

struct RunSettings {
    double duration = 0.0;           // seconds of simulated time to run; 0 = indefinite (runs until stopped)
    double sampleHz = 100.0;         // telemetry rows per simulated second
};

// ------------------------------------------------------------------ the model
struct Model {
    std::string name = "Untitled";
    std::string notes;
    std::vector<Body> bodies;
    std::vector<Link> links;
    Environment env;
    RunSettings run;

    void updateMass();                               // recompute mass, inertia of every body
    int addBody(const Body& b);                      // returns index
    void removeBody(int i);                          // also removes links that touch it
    int addLink(LinkKind kind, int a, int b, Vec2 worldPointA, Vec2 worldPointB);   // -1 if refused
    // A support: makes a fixed ground point at worldPoint (angleRad orients its symbol and a roller's sliding axis) and joins `body` to it
    // with a Pin (hinge), Weld (fixed / cantilever) or Roller. Returns the link index, or -1.
    int addSupport(LinkKind kind, int body, Vec2 worldPoint, double angleRad);
    void removeLink(int i);
    void refreshAutoRest();                          // springs without a hand-set rest length follow their drawn length
    Vec2 worldPoint(int body, Vec2 local) const;     // initial-pose attachment point in world coordinates
    int dynamicCount() const;
    std::string uniqueName(const std::string& base) const;
};

// Ready-made bodies the user can drop onto the canvas.
Body makeCircle(double radius, const Material& m, Vec2 pos);
Body makeBox(double w, double h, const Material& m, Vec2 pos);
Body makeRegular(int sides, double radius, const Material& m, Vec2 pos);
Body makeWedge(double w, double h, const Material& m, Vec2 pos);
Body makeFloor(double length, double angleDeg, const Material& m, Vec2 pos);   // a zero-thickness hatched line: floor, wall or ramp
Body makeBeam(double length, double thickness, const Material& m, Vec2 pos);   // a rigid beam: it FALLS unless supported
Body makeAnchor(Vec2 pos);

}  // namespace vlab
